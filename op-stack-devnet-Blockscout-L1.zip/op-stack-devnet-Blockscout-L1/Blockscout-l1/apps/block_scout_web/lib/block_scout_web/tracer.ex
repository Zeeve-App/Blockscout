defmodule BlockScoutWeb.Tracer do
  @moduledoc false

  use Spandex.Tracer, otp_app: :block_scout_web
end
