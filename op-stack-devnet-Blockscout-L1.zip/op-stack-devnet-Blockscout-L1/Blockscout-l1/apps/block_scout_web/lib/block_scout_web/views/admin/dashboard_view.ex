defmodule BlockScoutWeb.Admin.DashboardView do
  use BlockScoutWeb, :view
end
