defmodule BlockScoutWeb.Tokens.Instance.TransferView do
  use BlockScoutWeb, :view

  alias BlockScoutWeb.Tokens.Instance.OverviewView
end
