defmodule BlockScoutWeb.AddressContractVerificationViaMultiPartFilesView do
  use BlockScoutWeb, :view

  alias Explorer.Chain
  alias Explorer.Chain.SmartContract
  alias Explorer.SmartContract.RustVerifierInterface
end
