defmodule BlockScoutWeb.AddressWithdrawalView do
  use BlockScoutWeb, :view
end
