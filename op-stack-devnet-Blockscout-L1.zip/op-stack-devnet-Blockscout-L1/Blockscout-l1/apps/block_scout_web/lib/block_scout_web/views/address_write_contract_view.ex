defmodule BlockScoutWeb.AddressWriteContractView do
  use BlockScoutWeb, :view
end
