# Javascript structure files

## lib

* This folder is used to place `component` files, that may span in multiple pages.

## pages

* This folder is used to place `page` specific files, that won't be reusable in other locations.
