# Blockscout Explorer for L1

Welcome to the Blockscout Explorer for L1! 🚀

To get started and launch the explorer, please follow these steps:

1. Ensure you have Docker & Docker Compose installed on your machine.

2. Open a terminal and navigate to the directory where you have the Blockscout setup.

3. Run the following command to start the explorer in the background:
   
   docker-compose up -d
